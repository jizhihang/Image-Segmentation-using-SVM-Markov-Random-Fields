clc;
clear all; 
close all;
% warning('off','all');
addpath('C:\Users\ndy102\Downloads\markov_random_fields_with_ICS-2015-05-19\code-2015-05-23\code\');
idl = imread('C:\Users\ndy102\Downloads\markov_random_fields_with_ICS-2015-05-19\test1.jpg');
[ imb,m,n ] = preprocessing( idl );
% displayimages(imb); 
[ bbc ] = bbcalc(imb,m,n);
%  displayimages(idl,bbc,m,n);
final=idl(bbc(1):bbc(2),bbc(3):bbc(4),:);
x=final;
value=[1,-1];
num_classes = 2;
max_num_iterations=5;
[m n k] = size(x);
y= zeros(m,n);
%initial random assignment
for i=1:m
    for j=1:n
        r= randn(1);
        if(r>0.5)
            y(i,j)=value(2);
        else
            y(i,j)=value(1);
        end
    end
end
x=rgb2gray(x);
x= im2double(x);
[ mu, sigma ] =gaussian_densities_calculator( x );
termss=[];
for i=1:max_num_iterations
    for j=2:m-1             %ignore borders
        for k=2:n-1
%          r1=rand(1);
%          r2=r1*m*n;
%          j1= round(r2/n);
%          k1=round(r2/m);
%          if(j1<=1)
%              j1=j1+2;
%          end
%          if(j1>=m-1)
%              j1=j1-2;
%          end
%          if(k1>=n-1)
%              k1=k1-2;
%          end
%          if(k1<=1)
%              k1=k1+2;
%          
%          end
              j1=j; k1=k;  
         [class,terms] =  energy_calculator(j1,k1,y,x,value,mu,sigma);
         y(j1,k1)= class; 
          termss=[termss;terms];
        end
    end
end
           
z = (y+1 )/2;          
figure,imshow(z,[]);