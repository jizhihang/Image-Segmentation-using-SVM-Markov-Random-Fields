function [ y ] = ICS( x )
%ICS Summary of this function goes here
%   Detailed explanation goes here
value=[1,-1];
num_classes = 2;
max_num_iterations=2;
[m n k] = size(x);
y= zeros(m,n);
%initial random assignment
for i=1:m
    for j=1:n
        r= randn(1);
        if(r>0.5)
            y(i,j)=value(2);
        end
    end
end
x= im2double(x);
[ mu, sigma ] =gaussian_densities_calculator( x );

for i=1:max_num_iterations
    for j=2:m-1             %ignore borders
        for k=2:n-1
         r1=rand(1);
         r2=r1*m*n;
         j1= round(r2/n);
         k1=round(r2/m);
         if(j1<=1)
             j1=j1+2;
         end
         if(j1>=m-1)
             j1=j1-2;
         end
         if(k1>=n-1)
             k1=k1-2;
         end
         if(k1<=1)
             k1=k1+2;
         
         end
                
         class =  energy_calculator(j1,k1,y,x,value,mu,sigma);
         y(i,j)= class; 
          
        end
    end
end
           
y = (y+1 )/2;            
    
    
    